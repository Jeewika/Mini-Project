package org.airreservation.project;

	public class Flight {
			String flightNo;
			String sheetNO;
			Customer customer;
	
	//Constructor
		public Flight(String string) {
			this.flightNo = "UL-440";
			this.sheetNO = "Unkown SheetNo";
		}
//Receiving sheet number
	public String getsheetNO() {
			return sheetNO;
		}

	public void setsheetNO(String sheetNO) {
			this.sheetNO = sheetNO;
		}

	public String getflightNo() {
			return flightNo;
		}

	public void setCustomer(Customer c2) {
			this.customer = c2;
		
		}

	public Customer getCustomer() {
		
			return this.customer;
		}

}
