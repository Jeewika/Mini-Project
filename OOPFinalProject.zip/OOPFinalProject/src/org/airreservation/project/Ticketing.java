package org.airreservation.project;

import java.util.ArrayList;

public class Ticketing {

	String name;
	ArrayList<Flight> flights;
	ArrayList<Customer> customers;
	
//Constructor
public Ticketing(String name) {
	this.name = name;
	flights = new ArrayList<Flight>();
	customers = new ArrayList<Customer>();
}

public String getName() {
	return name;
}

//Get Flights information
public ArrayList<Flight> getFlights() {
	return flights;
}

public ArrayList<Customer> getCustomer() {
	return customers;
}
// Add new Flight
public void addFlight(Flight f1) {
	this.flights.add(f1);	
}
//Remove exciting Flight
public void removeFlight(Flight f1) {
	this.flights.remove(f1);
}

//Add New Customer
public void addCustomer(Customer p1) {
	this.customers.add(p1);
}

//Remove Customer
public void removeCustomer(Customer p1) {
	this.customers.remove(p1);
}

public boolean BookSheet(Flight f1, Customer p1) {
	int flightsOut = this.getFlightsForCustomer(p1).size();
	if ((f1.getCustomer() == null) &&
			flightsOut < p1.getMaximumTickets()){
			
		
	f1.setCustomer(p1);
	return true;
	}
		else {
			return false;
		}
	
}


public ArrayList<Flight> getFlightsForCustomer(Customer p1) {
	ArrayList<Flight> result = new ArrayList<Flight>();
	for (Flight aFlight : this.getFlights()) {
		if ((aFlight.getCustomer() != null) &&
				(aFlight.getCustomer().getName()
						.equals(p1.getName())))
		
		{
			result.add(aFlight);
		}
	}
	return result;
}

public ArrayList<Flight> getAvailableFlights() {
	ArrayList<Flight> result = new ArrayList<Flight>();
		for (Flight aFlight : this.getFlights()) {
			if (aFlight.getCustomer() == null) {
				result.add(aFlight);
			}
		}
		return result;
	}

public ArrayList<Flight> getUnavailableFlights() {
	ArrayList<Flight> result = new ArrayList<Flight>();
		for (Flight aFlight : this.getFlights()) {
			if (aFlight.getCustomer() != null) {
				result.add(aFlight);
			}
		}
		return result;
	}

public String toString() {
	return this.getName() + ": " +
			this.getFlights().size() + " flights; " +
			this.getCustomer().size() + " customers.";
	}

public static void main(String[] args) {
	// create a new Ticketing
	Ticketing testLibrary = new Ticketing("Test Booking");
	Flight f1 = new Flight("UL-110");
	Flight f2 = new Flight("UL-120");
	f1.setsheetNO("B-1");
	f2.setsheetNO("E-1");
	Customer customer1 = new Customer();
	Customer customer2 = new Customer();
	customer1.setName("customer1");
	customer2.setName("customer2");
	testLibrary.addFlight(f1);
	testLibrary.addFlight(f2);
	testLibrary.addCustomer(customer1);
	testLibrary.addCustomer(customer2);
	System.out.println("Test Booking");
	testLibrary.print();
	System.out.println("Reserved UL-110 sheet to customer2");
	testLibrary.BookSheet(f1, customer2);
	testLibrary.print();
	
	testLibrary.BookSheet(f2, customer1);
	testLibrary.print();
}

private void print() {
	System.out
		.println(" Report of Ticketing\n" +
				this.toString());
	for (Flight thisFlight : this.getFlights()) {
		System.out.println(thisFlight);
	}
	for (Customer p : this.getCustomer()) {
		int count = this.getFlightsForCustomer(p).size();
		System.out.println(p + " (for  " + count
										+ " of  flights)");
	}
	System.out.println("Flights Available: "
				+ this.getAvailableFlights().size());
	
	}
}


