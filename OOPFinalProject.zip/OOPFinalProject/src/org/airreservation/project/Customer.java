package org.airreservation.project;

public class Customer {
	// fields
			private String name; // Name of Customer
			private int maximumTickets;// Max ticket that customer can buy
		
	// constructor
			public Customer() {
				name = "unknown name";
				maximumTickets = 3;
				}

	//methods
			public String getName() {
				return name;
				}

		public void setName(String name) {
				this.name = name;
				}

		public int getMaximumTickets() {
				return maximumTickets;
				}

		public void setMaximumTickets(int maximumTickets) {
				this.maximumTickets = maximumTickets;
				}
		
		public String toString() {
				return this.getName()+ " ("+ this.getMaximumTickets()+ " Tickets)";
			
				}
		
		

}
