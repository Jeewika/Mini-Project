package org.airreservation.project;

import junit.framework.TestCase;

public class FlightTest extends TestCase {
	public void testFlight() {
		Flight f1 = new Flight("UL-440");
		assertEquals("UL-440", f1.flightNo);
		assertEquals("Unkown SheetNo", f1.sheetNO);
	}
	
	public void testGetCustomer() {
		Flight c2 = new Flight("UL-440");
		Customer p2 = new Customer();
		p2.setName("customer3");
		
		// method to receive flight sheet to a customer
		c2.setCustomer(p2);
		
		// get the name of the customer who has sheet

			String testName = c2.getCustomer().getName();
		assertEquals("customer3", testName);
		
	}

}
