package org.airreservation.project;


import junit.framework.TestCase;

public class CustomerTest extends TestCase {
	public void testCustomer() {
		Customer p1 = new Customer();
		assertEquals("unknown name", p1.getName());
		assertEquals(3, p1.getMaximumTickets());
	}

	public void testSetName() {
		Customer p2 = new Customer();
		p2.setName("Fred");
		assertEquals("Fred", p2.getName());
	}

	public void testSetMaximumTickets() {
		Customer p3 = new Customer();
		p3.setMaximumTickets(3);
		assertEquals(3, p3.getMaximumTickets());
	}
	
	public void testToString() {
		Customer p4 = new Customer();
		p4.setName("Customer");
		p4.setMaximumTickets(5);
		String testString = "Customer (5 Tickets)";
		assertEquals(testString, p4.toString());
	}


}
