package org.airreservation.project;

import java.util.ArrayList;

import junit.framework.TestCase;

public class TicketingTest extends TestCase {
	private Flight f1;
	private Flight f2;
	private Customer cu1;
	private Customer cu2;
	private Ticketing t1;
	// test constructor
	public void testTicketing() {
		Ticketing m1 = new Ticketing("Test");
		
		assertEquals("Test", m1.name);
		
		assertTrue(m1.flights instanceof ArrayList);
		assertTrue(m1.customers instanceof ArrayList);
		}
	public void setup() {
		f1 = new Flight("Flight1");
		f2 = new Flight("Flight2");
		cu1 = new Customer();
		cu2 = new Customer();
		cu1.setName("Fred");
		cu2.setName("Sue");
		t1 = new Ticketing("Test");
	}
	public void testAddFlight() {
		//create test objects
		setup();
		//test initial size is 0
		assertEquals(0, t1.getFlights().size());
		t1.addFlight(f1);
		t1.addFlight(f2);
		assertEquals(2, t1.getFlights().size());
		assertEquals(0, t1.getFlights().indexOf(f1));
		assertEquals(1, t1.getFlights().indexOf(f2));
		t1.removeFlight(f1);
		assertEquals(1, t1.getFlights().size());
		assertEquals(0, t1.getFlights().indexOf(f2));
		t1.removeFlight(f2);
		assertEquals(0, t1.getFlights().size());
		}
	
	public void BookSheet() {
		// set up objects
		setup();
		addItems();
		
		assertTrue("Flight did not received correctly",
		t1.BookSheet(f1,cu1));
		assertFalse("Flight was already received",
		t1.BookSheet(f1,cu2));

		// additional test for maximumFlights
		setup();
		cu1.setMaximumTickets(1);
		addItems();
		
		assertTrue("First Flight did not received",
				t1.BookSheet(f2, cu1));
		assertFalse("Second Flight should not have received",
				t1.BookSheet(f1, cu1));
		}
	private void addItems() {
		t1.addFlight(f1);
		t1.addFlight(f2);
		t1.addCustomer(cu1);
		t1.addCustomer(cu2);
	}
	
	public void testGetFlightsForCustomer() {
		setup();
		addItems();
		assertEquals(0, t1.getFlightsForCustomer(cu1).size());
		t1.BookSheet(f1, cu1);
		ArrayList<Flight> testFlights = t1.getFlightsForCustomer(cu1);
		assertEquals(1, testFlights.size());
		assertEquals(0, testFlights.indexOf(f1));
		t1.BookSheet(f2, cu1);
		testFlights = t1.getFlightsForCustomer(cu1);
		assertEquals(2, testFlights.size());
		assertEquals(1, testFlights.indexOf(f2));
		}
	
	public void testGetAvailableFlights() {
		setup();
		addItems();
		ArrayList<Flight> testFlights = t1.getAvailableFlights();
		assertEquals(2, testFlights.size());
		assertEquals(1, testFlights.indexOf(f2));
		t1.BookSheet(f1, cu1);
		testFlights = t1.getAvailableFlights();
		assertEquals(1, testFlights.size());
		assertEquals(0, testFlights.indexOf(f2));
		t1.BookSheet(f2, cu1);
		testFlights = t1.getAvailableFlights();
		assertEquals(0, testFlights.size());
		}
	
	public void testGetUnavailableFlights() {
		setup();
		addItems();
		assertEquals(0, t1.getUnavailableFlights().size());
		t1.BookSheet(f1, cu1);
		ArrayList<Flight> testFlights = t1.getUnavailableFlights();
		assertEquals(1, testFlights.size());
		assertEquals(0, testFlights.indexOf(f1));
		t1.BookSheet(f2, cu2);
		testFlights = t1.getUnavailableFlights();
		assertEquals(2, testFlights.size());
		assertEquals(1, testFlights.indexOf(f2));
		}
	
	public void testToString() {
		setup();
		addItems();
		assertEquals("Test: 2 flights; 2 customers.",
		t1.toString());
		}

}
